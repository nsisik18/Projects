/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/user/Desktop/204/LabProje/ProjeCode.vhd";
extern char *IEEE_P_3620187407;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );
char *ieee_p_3620187407_sub_767668596_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_3489044871_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(65, ng0);

LAB3:    t1 = (t0 + 3752U);
    t2 = *((char **)t1);
    t1 = (t0 + 9112);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 8872);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3489044871_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(66, ng0);

LAB3:    t1 = (t0 + 3592U);
    t2 = *((char **)t1);
    t1 = (t0 + 9176);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 8888);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3489044871_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(67, ng0);

LAB3:    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    t1 = (t0 + 9240);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 8904);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3489044871_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(68, ng0);

LAB3:    t1 = (t0 + 3112U);
    t2 = *((char **)t1);
    t1 = (t0 + 9304);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 8920);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3489044871_3212880686_p_4(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(69, ng0);

LAB3:    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t2 = (t0 + 14232U);
    t4 = (t0 + 4392U);
    t5 = *((char **)t4);
    t4 = (t0 + 14264U);
    t6 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t1, t3, t2, t5, t4);
    t7 = (t1 + 12U);
    t8 = *((unsigned int *)t7);
    t9 = (1U * t8);
    t10 = (7U != t9);
    if (t10 == 1)
        goto LAB5;

LAB6:    t11 = (t0 + 9368);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 7U);
    xsi_driver_first_trans_fast_port(t11);

LAB2:    t16 = (t0 + 8936);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(7U, t9, 0);
    goto LAB6;

}

static void work_a_3489044871_3212880686_p_5(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(70, ng0);

LAB3:    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t2 = (t0 + 14216U);
    t4 = (t0 + 4232U);
    t5 = *((char **)t4);
    t4 = (t0 + 14248U);
    t6 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t1, t3, t2, t5, t4);
    t7 = (t1 + 12U);
    t8 = *((unsigned int *)t7);
    t9 = (1U * t8);
    t10 = (7U != t9);
    if (t10 == 1)
        goto LAB5;

LAB6:    t11 = (t0 + 9432);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 7U);
    xsi_driver_first_trans_fast_port(t11);

LAB2:    t16 = (t0 + 8952);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(7U, t9, 0);
    goto LAB6;

}

static void work_a_3489044871_3212880686_p_6(char *t0)
{
    char t21[16];
    char t23[16];
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t22;
    char *t24;
    char *t25;
    unsigned char t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    t3 = (1 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 2952U);
    t9 = *((char **)t8);
    t10 = (0 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 9496);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t15;
    xsi_driver_first_trans_fast(t16);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 3112U);
    t2 = *((char **)t1);
    t3 = (1 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 3112U);
    t9 = *((char **)t8);
    t10 = (0 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 9560);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t15;
    xsi_driver_first_trans_fast(t16);
    xsi_set_current_line(79, ng0);
    t1 = (t0 + 992U);
    t7 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t7 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 8968);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(82, ng0);
    t2 = (t0 + 3752U);
    t8 = *((char **)t2);
    t2 = (t0 + 14200U);
    t9 = (t0 + 14384);
    t17 = (t21 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 0;
    t18 = (t17 + 4U);
    *((int *)t18) = 3;
    t18 = (t17 + 8U);
    *((int *)t18) = 1;
    t3 = (3 - 0);
    t4 = (t3 * 1);
    t4 = (t4 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t4;
    t15 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t8, t2, t9, t21);
    if (t15 == 1)
        goto LAB8;

LAB9:    t14 = (unsigned char)0;

LAB10:    if (t14 != 0)
        goto LAB5;

LAB7:
LAB6:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 5088U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t7 = (t3 == 0);
    if (t7 != 0)
        goto LAB20;

LAB22:
LAB21:    goto LAB3;

LAB5:    xsi_set_current_line(83, ng0);
    t25 = (t0 + 5088U);
    t27 = *((char **)t25);
    t25 = (t27 + 0);
    *((int *)t25) = 1;
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 9624);
    t2 = (t1 + 56U);
    t8 = *((char **)t2);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(86, ng0);
    t1 = (t0 + 14392);
    t8 = (t0 + 9688);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t1, 4U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(87, ng0);
    t1 = (t0 + 3912U);
    t2 = *((char **)t1);
    t1 = (t0 + 14216U);
    t8 = (t0 + 4232U);
    t9 = *((char **)t8);
    t8 = (t0 + 14248U);
    t16 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t21, t2, t1, t9, t8);
    t17 = (t0 + 4072U);
    t18 = *((char **)t17);
    t17 = (t0 + 14232U);
    t19 = (t0 + 4392U);
    t20 = *((char **)t19);
    t19 = (t0 + 14264U);
    t22 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t23, t18, t17, t20, t19);
    t7 = ieee_std_logic_unsigned_greater_stdv_stdv(IEEE_P_3620187407, t16, t21, t22, t23);
    if (t7 != 0)
        goto LAB11;

LAB13:
LAB12:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 4072U);
    t2 = *((char **)t1);
    t1 = (t0 + 14232U);
    t8 = (t0 + 4392U);
    t9 = *((char **)t8);
    t8 = (t0 + 14264U);
    t16 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t21, t2, t1, t9, t8);
    t17 = (t0 + 3912U);
    t18 = *((char **)t17);
    t17 = (t0 + 14216U);
    t19 = (t0 + 4232U);
    t20 = *((char **)t19);
    t19 = (t0 + 14248U);
    t22 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t23, t18, t17, t20, t19);
    t7 = ieee_std_logic_unsigned_greater_stdv_stdv(IEEE_P_3620187407, t16, t21, t22, t23);
    if (t7 != 0)
        goto LAB14;

LAB16:
LAB15:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4072U);
    t2 = *((char **)t1);
    t1 = (t0 + 14232U);
    t8 = (t0 + 4392U);
    t9 = *((char **)t8);
    t8 = (t0 + 14264U);
    t16 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t21, t2, t1, t9, t8);
    t17 = (t0 + 3912U);
    t18 = *((char **)t17);
    t17 = (t0 + 14216U);
    t19 = (t0 + 4232U);
    t20 = *((char **)t19);
    t19 = (t0 + 14248U);
    t22 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t23, t18, t17, t20, t19);
    t7 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t16, t21, t22, t23);
    if (t7 != 0)
        goto LAB17;

LAB19:
LAB18:    goto LAB6;

LAB8:    t18 = (t0 + 3592U);
    t19 = *((char **)t18);
    t18 = (t0 + 14184U);
    t20 = (t0 + 14388);
    t24 = (t23 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = 0;
    t25 = (t24 + 4U);
    *((int *)t25) = 3;
    t25 = (t24 + 8U);
    *((int *)t25) = 1;
    t10 = (3 - 0);
    t4 = (t10 * 1);
    t4 = (t4 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t4;
    t26 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t19, t18, t20, t23);
    t14 = t26;
    goto LAB10;

LAB11:    xsi_set_current_line(88, ng0);
    t24 = (t0 + 14396);
    t27 = (t0 + 9752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t24, 2U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB12;

LAB14:    xsi_set_current_line(91, ng0);
    t24 = (t0 + 14398);
    t27 = (t0 + 9752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t24, 2U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB15;

LAB17:    xsi_set_current_line(94, ng0);
    t24 = (t0 + 14400);
    t27 = (t0 + 9752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t24, 2U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB18;

LAB20:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 3432U);
    t8 = *((char **)t1);
    t14 = *((unsigned char *)t8);
    t1 = (t0 + 2952U);
    t9 = *((char **)t1);
    t4 = (3 - 3);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t9 + t6);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t23 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = 3;
    t19 = (t18 + 4U);
    *((int *)t19) = 1;
    t19 = (t18 + 8U);
    *((int *)t19) = -1;
    t10 = (1 - 3);
    t11 = (t10 * -1);
    t11 = (t11 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t11;
    t16 = xsi_base_array_concat(t16, t21, t17, (char)99, t14, (char)97, t1, t23, (char)101);
    t11 = (1U + 3U);
    t15 = (4U != t11);
    if (t15 == 1)
        goto LAB23;

LAB24:    t19 = (t0 + 9816);
    t20 = (t19 + 56U);
    t22 = *((char **)t20);
    t24 = (t22 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t16, 4U);
    xsi_driver_first_trans_fast(t19);
    xsi_set_current_line(101, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t7 = *((unsigned char *)t2);
    t1 = (t0 + 3112U);
    t8 = *((char **)t1);
    t4 = (3 - 3);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t8 + t6);
    t16 = ((IEEE_P_2592010699) + 4024);
    t17 = (t23 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 3;
    t18 = (t17 + 4U);
    *((int *)t18) = 1;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t3 = (1 - 3);
    t11 = (t3 * -1);
    t11 = (t11 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t11;
    t9 = xsi_base_array_concat(t9, t21, t16, (char)99, t7, (char)97, t1, t23, (char)101);
    t11 = (1U + 3U);
    t14 = (4U != t11);
    if (t14 == 1)
        goto LAB25;

LAB26:    t18 = (t0 + 9880);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t22 = (t20 + 56U);
    t24 = *((char **)t22);
    memcpy(t24, t9, 4U);
    xsi_driver_first_trans_fast(t18);
    xsi_set_current_line(104, ng0);
    t1 = (t0 + 3752U);
    t2 = *((char **)t1);
    t1 = (t0 + 14200U);
    t8 = (t0 + 14402);
    t16 = (t21 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = 0;
    t17 = (t16 + 4U);
    *((int *)t17) = 3;
    t17 = (t16 + 8U);
    *((int *)t17) = 1;
    t3 = (3 - 0);
    t4 = (t3 * 1);
    t4 = (t4 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t4;
    t7 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t8, t21);
    if (t7 != 0)
        goto LAB27;

LAB29:    xsi_set_current_line(107, ng0);
    t1 = (t0 + 3752U);
    t2 = *((char **)t1);
    t1 = (t0 + 14200U);
    t8 = (t0 + 14410);
    t16 = (t23 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = 0;
    t17 = (t16 + 4U);
    *((int *)t17) = 3;
    t17 = (t16 + 8U);
    *((int *)t17) = 1;
    t3 = (3 - 0);
    t4 = (t3 * 1);
    t4 = (t4 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t4;
    t17 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t21, t2, t1, t8, t23);
    t18 = (t21 + 12U);
    t4 = *((unsigned int *)t18);
    t5 = (1U * t4);
    t7 = (4U != t5);
    if (t7 == 1)
        goto LAB30;

LAB31:    t19 = (t0 + 9688);
    t20 = (t19 + 56U);
    t22 = *((char **)t20);
    t24 = (t22 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t17, 4U);
    xsi_driver_first_trans_fast(t19);

LAB28:    xsi_set_current_line(110, ng0);
    t1 = (t0 + 4968U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t7 = (t3 == 10);
    if (t7 != 0)
        goto LAB32;

LAB34:
LAB33:    xsi_set_current_line(114, ng0);
    t1 = (t0 + 4968U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t10 = (t3 + 1);
    t1 = (t0 + 4968U);
    t8 = *((char **)t1);
    t1 = (t8 + 0);
    *((int *)t1) = t10;
    goto LAB21;

LAB23:    xsi_size_not_matching(4U, t11, 0);
    goto LAB24;

LAB25:    xsi_size_not_matching(4U, t11, 0);
    goto LAB26;

LAB27:    xsi_set_current_line(105, ng0);
    t17 = (t0 + 14406);
    t19 = (t0 + 9688);
    t20 = (t19 + 56U);
    t22 = *((char **)t20);
    t24 = (t22 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t17, 4U);
    xsi_driver_first_trans_fast(t19);
    goto LAB28;

LAB30:    xsi_size_not_matching(4U, t5, 0);
    goto LAB31;

LAB32:    xsi_set_current_line(111, ng0);
    t1 = (t0 + 4968U);
    t8 = *((char **)t1);
    t1 = (t8 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(112, ng0);
    t1 = (t0 + 3592U);
    t2 = *((char **)t1);
    t1 = (t0 + 14184U);
    t8 = (t0 + 14414);
    t16 = (t23 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = 0;
    t17 = (t16 + 4U);
    *((int *)t17) = 3;
    t17 = (t16 + 8U);
    *((int *)t17) = 1;
    t3 = (3 - 0);
    t4 = (t3 * 1);
    t4 = (t4 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t4;
    t17 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t21, t2, t1, t8, t23);
    t18 = (t21 + 12U);
    t4 = *((unsigned int *)t18);
    t5 = (1U * t4);
    t7 = (4U != t5);
    if (t7 == 1)
        goto LAB35;

LAB36:    t19 = (t0 + 9944);
    t20 = (t19 + 56U);
    t22 = *((char **)t20);
    t24 = (t22 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t17, 4U);
    xsi_driver_first_trans_fast(t19);
    goto LAB33;

LAB35:    xsi_size_not_matching(4U, t5, 0);
    goto LAB36;

}

static void work_a_3489044871_3212880686_p_7(char *t0)
{
    char t16[16];
    char t20[16];
    char *t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t17;
    char *t18;
    char *t21;
    char *t22;
    int t23;
    unsigned int t24;
    char *t25;
    unsigned int t26;
    unsigned char t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    xsi_set_current_line(123, ng0);
    t1 = (t0 + 2272U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 8984);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(124, ng0);
    t4 = (t0 + 3112U);
    t5 = *((char **)t4);
    t6 = (0 - 3);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t4 = (t5 + t9);
    t10 = *((unsigned char *)t4);
    t11 = (t10 == (unsigned char)3);
    if (t11 == 1)
        goto LAB8;

LAB9:    t3 = (unsigned char)0;

LAB10:    if (t3 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(125, ng0);
    t12 = (t0 + 4072U);
    t17 = *((char **)t12);
    t12 = (t0 + 14232U);
    t18 = (t0 + 14418);
    t21 = (t20 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 0;
    t22 = (t21 + 4U);
    *((int *)t22) = 6;
    t22 = (t21 + 8U);
    *((int *)t22) = 1;
    t23 = (6 - 0);
    t24 = (t23 * 1);
    t24 = (t24 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t24;
    t22 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t16, t17, t12, t18, t20);
    t25 = (t16 + 12U);
    t24 = *((unsigned int *)t25);
    t26 = (1U * t24);
    t27 = (7U != t26);
    if (t27 == 1)
        goto LAB11;

LAB12:    t28 = (t0 + 10008);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    memcpy(t32, t22, 7U);
    xsi_driver_first_trans_fast(t28);
    goto LAB6;

LAB8:    t12 = (t0 + 4552U);
    t13 = *((char **)t12);
    t14 = *((unsigned char *)t13);
    t15 = (t14 == (unsigned char)2);
    t3 = t15;
    goto LAB10;

LAB11:    xsi_size_not_matching(7U, t26, 0);
    goto LAB12;

}

static void work_a_3489044871_3212880686_p_8(char *t0)
{
    char t16[16];
    char t20[16];
    char *t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t17;
    char *t18;
    char *t21;
    char *t22;
    int t23;
    unsigned int t24;
    char *t25;
    unsigned int t26;
    unsigned char t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    xsi_set_current_line(132, ng0);
    t1 = (t0 + 2112U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 9000);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(133, ng0);
    t4 = (t0 + 3112U);
    t5 = *((char **)t4);
    t6 = (0 - 3);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t4 = (t5 + t9);
    t10 = *((unsigned char *)t4);
    t11 = (t10 == (unsigned char)2);
    if (t11 == 1)
        goto LAB8;

LAB9:    t3 = (unsigned char)0;

LAB10:    if (t3 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(134, ng0);
    t12 = (t0 + 4392U);
    t17 = *((char **)t12);
    t12 = (t0 + 14264U);
    t18 = (t0 + 14425);
    t21 = (t20 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 0;
    t22 = (t21 + 4U);
    *((int *)t22) = 6;
    t22 = (t21 + 8U);
    *((int *)t22) = 1;
    t23 = (6 - 0);
    t24 = (t23 * 1);
    t24 = (t24 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t24;
    t22 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t16, t17, t12, t18, t20);
    t25 = (t16 + 12U);
    t24 = *((unsigned int *)t25);
    t26 = (1U * t24);
    t27 = (7U != t26);
    if (t27 == 1)
        goto LAB11;

LAB12:    t28 = (t0 + 10072);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    memcpy(t32, t22, 7U);
    xsi_driver_first_trans_fast(t28);
    goto LAB6;

LAB8:    t12 = (t0 + 4552U);
    t13 = *((char **)t12);
    t14 = *((unsigned char *)t13);
    t15 = (t14 == (unsigned char)2);
    t3 = t15;
    goto LAB10;

LAB11:    xsi_size_not_matching(7U, t26, 0);
    goto LAB12;

}

static void work_a_3489044871_3212880686_p_9(char *t0)
{
    char t16[16];
    char t20[16];
    char *t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t17;
    char *t18;
    char *t21;
    char *t22;
    int t23;
    unsigned int t24;
    char *t25;
    unsigned int t26;
    unsigned char t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    xsi_set_current_line(141, ng0);
    t1 = (t0 + 2432U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 9016);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(142, ng0);
    t4 = (t0 + 2952U);
    t5 = *((char **)t4);
    t6 = (0 - 3);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t4 = (t5 + t9);
    t10 = *((unsigned char *)t4);
    t11 = (t10 == (unsigned char)2);
    if (t11 == 1)
        goto LAB8;

LAB9:    t3 = (unsigned char)0;

LAB10:    if (t3 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(143, ng0);
    t12 = (t0 + 4232U);
    t17 = *((char **)t12);
    t12 = (t0 + 14248U);
    t18 = (t0 + 14432);
    t21 = (t20 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 0;
    t22 = (t21 + 4U);
    *((int *)t22) = 6;
    t22 = (t21 + 8U);
    *((int *)t22) = 1;
    t23 = (6 - 0);
    t24 = (t23 * 1);
    t24 = (t24 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t24;
    t22 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t16, t17, t12, t18, t20);
    t25 = (t16 + 12U);
    t24 = *((unsigned int *)t25);
    t26 = (1U * t24);
    t27 = (7U != t26);
    if (t27 == 1)
        goto LAB11;

LAB12:    t28 = (t0 + 10136);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    memcpy(t32, t22, 7U);
    xsi_driver_first_trans_fast(t28);
    goto LAB6;

LAB8:    t12 = (t0 + 4552U);
    t13 = *((char **)t12);
    t14 = *((unsigned char *)t13);
    t15 = (t14 == (unsigned char)2);
    t3 = t15;
    goto LAB10;

LAB11:    xsi_size_not_matching(7U, t26, 0);
    goto LAB12;

}

static void work_a_3489044871_3212880686_p_10(char *t0)
{
    char t16[16];
    char t20[16];
    char *t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t17;
    char *t18;
    char *t21;
    char *t22;
    int t23;
    unsigned int t24;
    char *t25;
    unsigned int t26;
    unsigned char t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    xsi_set_current_line(149, ng0);
    t1 = (t0 + 2592U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 9032);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(150, ng0);
    t4 = (t0 + 2952U);
    t5 = *((char **)t4);
    t6 = (0 - 3);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t4 = (t5 + t9);
    t10 = *((unsigned char *)t4);
    t11 = (t10 == (unsigned char)3);
    if (t11 == 1)
        goto LAB8;

LAB9:    t3 = (unsigned char)0;

LAB10:    if (t3 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(151, ng0);
    t12 = (t0 + 4072U);
    t17 = *((char **)t12);
    t12 = (t0 + 14232U);
    t18 = (t0 + 14439);
    t21 = (t20 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 0;
    t22 = (t21 + 4U);
    *((int *)t22) = 6;
    t22 = (t21 + 8U);
    *((int *)t22) = 1;
    t23 = (6 - 0);
    t24 = (t23 * 1);
    t24 = (t24 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t24;
    t22 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t16, t17, t12, t18, t20);
    t25 = (t16 + 12U);
    t24 = *((unsigned int *)t25);
    t26 = (1U * t24);
    t27 = (7U != t26);
    if (t27 == 1)
        goto LAB11;

LAB12:    t28 = (t0 + 10200);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    memcpy(t32, t22, 7U);
    xsi_driver_first_trans_fast(t28);
    goto LAB6;

LAB8:    t12 = (t0 + 4552U);
    t13 = *((char **)t12);
    t14 = *((unsigned char *)t13);
    t15 = (t14 == (unsigned char)2);
    t3 = t15;
    goto LAB10;

LAB11:    xsi_size_not_matching(7U, t26, 0);
    goto LAB12;

}


extern void work_a_3489044871_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3489044871_3212880686_p_0,(void *)work_a_3489044871_3212880686_p_1,(void *)work_a_3489044871_3212880686_p_2,(void *)work_a_3489044871_3212880686_p_3,(void *)work_a_3489044871_3212880686_p_4,(void *)work_a_3489044871_3212880686_p_5,(void *)work_a_3489044871_3212880686_p_6,(void *)work_a_3489044871_3212880686_p_7,(void *)work_a_3489044871_3212880686_p_8,(void *)work_a_3489044871_3212880686_p_9,(void *)work_a_3489044871_3212880686_p_10};
	xsi_register_didat("work_a_3489044871_3212880686", "isim/ProjeSim_isim_beh.exe.sim/work/a_3489044871_3212880686.didat");
	xsi_register_executes(pe);
}
